package jag.chintu.shiva.forum;

import android.support.v7.app.*;
import android.os.*;
import android.widget.*;
import android.graphics.*;
import android.view.*;
import android.text.*;
import com.google.firebase.auth.*;
import com.google.android.gms.tasks.*;
import android.support.annotation.*;
import android.content.*;
import android.app.*;

public class Signin extends AppCompatActivity
{
    public static final String IS_USER_LOGIN = "IsUserLoggedIn";
    public static final String MyPREFERENCES = "MyPrefs";
    public static String uname;
    public static String uname1;
    private FirebaseAuth auth;
    ImageView back;
    private EditText inputEmail;
    private EditText inputPassword;
    SharedPreferences sharedpreferences;
    private TextView signin;
    private TextView topsignin;
    
    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.sharedpreferences = this.getSharedPreferences("MyPrefs", 0);
        if (this.sharedpreferences.getBoolean("IsUserLoggedIn", false)) {
            this.startActivity(new Intent((Context)this, (Class)Branch.class));
        }
        this.setContentView(2130968610);
        this.auth = FirebaseAuth.getInstance();
        Toast.makeText((Context)this, (CharSequence)"welcome", 1).show();
        this.inputEmail = (EditText)this.findViewById(2131493049);
        this.inputPassword = (EditText)this.findViewById(2131493050);
        this.signin = (TextView)this.findViewById(2131493044);
        this.topsignin = (TextView)this.findViewById(2131493048);
        this.back = (ImageView)this.findViewById(2131493047);
        final Typeface fromAsset = Typeface.createFromAsset(this.getAssets(), "bot1.ttf");
        this.signin.setTypeface(fromAsset);
        this.topsignin.setTypeface(fromAsset);
        this.inputEmail.setTypeface(fromAsset);
        this.inputPassword.setTypeface(fromAsset);
        this.signin.setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                final String string = Signin.this.inputEmail.getText().toString();
                final String string2 = Signin.this.inputPassword.getText().toString();
                if (TextUtils.isEmpty((CharSequence)string)) {
                    Toast.makeText(Signin.this.getApplicationContext(), (CharSequence)"Enter email address!", 0).show();
                }
                else if (TextUtils.isEmpty((CharSequence)string2)) {
                    Toast.makeText(Signin.this.getApplicationContext(), (CharSequence)"Enter password!", 0).show();
                }
                else {
                    Signin.this.auth.signInWithEmailAndPassword(string, string2).addOnCompleteListener(Signin.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull final Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                if (string2.length() < 6) {
                                    Toast.makeText(Signin.this.getApplicationContext(), (CharSequence)"Password too short, enter minimum 6 characters!", 0).show();
                                }
                                else {
                                    Toast.makeText((Context)Signin.this, (CharSequence)"authfailed", 1).show();
                                }
                            }
                            else {
                                Signin.uname = Signin.this.inputEmail.getText().toString();
                                final SharedPreferences$Editor edit = Signin.this.sharedpreferences.edit();
                                edit.putBoolean("IsUserLoggedIn", true);
                                edit.putString("use", Signin.uname);
                                edit.commit();
                                Toast.makeText((Context)Signin.this, (CharSequence)"Loggedin Succesfully", 1).show();
                                Signin.this.startActivity(new Intent((Context)Signin.this, (Class)Branch.class));
                            }
                        }
                    });
                }
            }
        });
        this.back.setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                Signin.this.startActivity(new Intent((Context)Signin.this, (Class)MainActivity.class));
            }
        });
    }
}
