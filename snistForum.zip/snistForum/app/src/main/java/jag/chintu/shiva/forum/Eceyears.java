package jag.chintu.shiva.forum;

import android.support.v7.app.*;
import java.util.*;
import android.widget.*;
import android.support.v7.widget.*;
import android.content.*;
import android.view.*;
import android.os.*;
import android.support.annotation.*;

public class Eceyears extends AppCompatActivity
{
    private ArrayList deom;
    Button y1;
    Button y2;
    Button y3;
    Button y4;
    
    public void intiative() {
        final RecyclerView recyclerView = (RecyclerView)this.findViewById(2131493033);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager(this.getApplicationContext()));
        (this.deom = new ArrayList()).add(new Deom("I YEAR", 2130837678));
        this.deom.add(new Deom("II YEAR", 2130837697));
        this.deom.add(new Deom("III YEAR", 2130837696));
        this.deom.add(new Deom("IV YEAR", 2130837650));
        recyclerView.setAdapter((RecyclerView.Adapter)new RVAdapter(this.deom));
        recyclerView.addOnItemTouchListener((RecyclerView.OnItemTouchListener)new RecyclerView.OnItemTouchListener() {
            GestureDetector gestureDetector = new GestureDetector(Eceyears.this.getApplicationContext(), (GestureDetector$OnGestureListener)new GestureDetector$SimpleOnGestureListener() {
                public boolean onSingleTapUp(final MotionEvent motionEvent) {
                    return true;
                }
            });
            
            @Override
            public boolean onInterceptTouchEvent(final RecyclerView recyclerView, final MotionEvent motionEvent) {
                final View childViewUnder = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());
                if (childViewUnder != null && this.gestureDetector.onTouchEvent(motionEvent)) {
                    final int childAdapterPosition = recyclerView.getChildAdapterPosition(childViewUnder);
                    if (childAdapterPosition == 0) {
                        Eceyears.this.startActivity(new Intent((Context)Eceyears.this, (Class)Cse1sub.class));
                    }
                    if (childAdapterPosition == 1) {
                        Eceyears.this.startActivity(new Intent((Context)Eceyears.this, (Class)Ece2sub.class));
                    }
                    if (childAdapterPosition == 2) {
                        Eceyears.this.startActivity(new Intent((Context)Eceyears.this, (Class)Ece3sub.class));
                    }
                    if (childAdapterPosition == 3) {
                        Eceyears.this.startActivity(new Intent((Context)Eceyears.this, (Class)Ece4sub.class));
                    }
                }
                return false;
            }
            
            @Override
            public void onRequestDisallowInterceptTouchEvent(final boolean b) {
            }
            
            @Override
            public void onTouchEvent(final RecyclerView recyclerView, final MotionEvent motionEvent) {
            }
        });
    }
    
    @Override
    protected void onCreate(@Nullable final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968642);
        this.intiative();
    }
}
