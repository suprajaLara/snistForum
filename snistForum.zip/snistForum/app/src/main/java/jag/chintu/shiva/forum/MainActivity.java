package jag.chintu.shiva.forum;

import android.app.AlertDialog;
import android.widget.*;
import android.support.v7.app.*;
import android.content.*;
import android.os.*;
import android.graphics.*;
import android.view.*;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity
{
    TextView quote;
    TextView signin;
    TextView signup;
    
    @Override
    public void onBackPressed() {

        new AlertDialog.Builder((Context)this).setIcon(17301543).setTitle("Exit").setMessage("Are you sure?").setPositiveButton("yes", (DialogInterface$OnClickListener)new DialogInterface$OnClickListener() {
            public void onClick(final DialogInterface dialogInterface, final int n) {
                final Intent intent = new Intent("android.intent.action.MAIN");
                intent.addCategory("android.intent.category.HOME");
                intent.setFlags(268435456);
                MainActivity.this.startActivity(intent);
                MainActivity.this.finish();
            }
        }).setNegativeButton("no", null).show();
    }
    
    @Override
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2130968608);
        this.signin = (TextView)this.findViewById(2131493044);
        this.signup = (TextView)this.findViewById(2131493045);
        this.quote = (TextView)this.findViewById(2131493042);
        final Typeface fromAsset = Typeface.createFromAsset(this.getAssets(), "bot1.ttf");
        this.signin.setTypeface(fromAsset);
        this.signup.setTypeface(fromAsset);
        this.quote.setTypeface(fromAsset);
        this.signin.setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                MainActivity.this.startActivity(new Intent((Context)MainActivity.this, (Class)Signin.class));
            }
        });
        this.signup.setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                MainActivity.this.startActivity(new Intent((Context)MainActivity.this, (Class)Signup.class));
            }
        });
    }
}
