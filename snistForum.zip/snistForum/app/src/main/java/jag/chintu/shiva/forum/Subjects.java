package jag.chintu.shiva.forum;

public class Subjects
{
    private String title;
    
    public Subjects() {
    }
    
    public Subjects(final String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(final String title) {
        this.title = title;
    }
}
